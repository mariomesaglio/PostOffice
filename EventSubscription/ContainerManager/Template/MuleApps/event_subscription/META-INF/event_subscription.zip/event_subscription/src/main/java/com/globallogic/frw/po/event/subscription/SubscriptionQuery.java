package com.globallogic.frw.po.event.subscription;

public class SubscriptionQuery {

	private String eventID;
	private String eventLabel;

	public String getEventID() {
		return eventID;
	}

	public void setEventID(String eventID) {
		this.eventID = eventID;
	}

	public String getEventLabel() {
		return eventLabel;
	}

	public void setEventLabel(String eventLabel) {
		this.eventLabel = eventLabel;
	}
	
}
